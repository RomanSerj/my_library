from setuptools import setup, find_packages

setup = (name = 'my_library',
         version = '1',
         packages=find_packages(),
         description='Кто знает тому не надо, а кто не знает - тому не поможет!',
         author='ce hleb',
         author_email='romsergeev8@gmail.com',
         url = 'https://github.com/RomanSerj/my_library')
