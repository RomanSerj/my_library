def find_factorial(n):
    if n < 0: #Проверка числа на знак
        return "Факториал не определен для отрицательных чисел."
    result = 1
    for i in range(1, n + 1):
        result *= i
    return result #Возвращение факториала
def arithmetic_progression(a1, d, n):
    return n / 2 * (2 * a1 + (n - 1) * d)
def find_max(lst):
    if not lst: #Проверка на список
        return None
    max_value = lst[0]
    for num in lst:
        if num > max_value:
            max_value = num
    return max_value
def merge_lists(lst1, lst2):
    return list(set(lst1) | set(lst2))
def geometric_progression(a1, r, n):
    if r == 1:
        return a1 * n
    return a1 * (1 - r**n) / (1 - r)
